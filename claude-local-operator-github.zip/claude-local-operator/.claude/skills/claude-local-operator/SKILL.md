---
name: claude-local-operator
description: Safely operate local desktop applications through an authorized local MCP automation server. Use when the user asks Claude to open software, observe the screen, click/type, control windows, or complete GUI workflows on their computer.
---

# Claude Local Operator

This skill teaches Claude how to safely control local desktop software **only through explicitly available local tools**, normally exposed by a trusted MCP server such as `local_operator`.

Important boundary:

> This skill does **not** give Claude direct computer-control powers by itself. It provides the operating procedure, safety policy, and expected tool contract. Actual control must come from a local MCP server or other Claude Code tools that the user has installed and authorized.

## When to use this skill

Use this skill when the user asks to:

- open, focus, or close a desktop application;
- inspect a GUI, window, dialog, screenshot, or app state;
- click buttons, type text, press shortcuts, drag, scroll, or navigate menus;
- automate a local workflow in software such as browsers, editors, office apps, design tools, IDEs, terminals, or custom desktop apps;
- debug a workflow by watching what happens on screen;
- create a repeatable local-app operation playbook.

Do **not** use it for ordinary code edits, CLI-only workflows, web research, or tasks that can be completed with file/search tools alone.

## Required authorization and safety rules

Before operating the local computer, establish that the current user is authorizing control of **their own machine or an explicitly authorized test environment**.

Never perform these without explicit per-action confirmation:

1. deleting, overwriting, encrypting, moving, or mass-modifying user files;
2. sending messages, emails, payments, posts, forms, purchases, or commits/pushes;
3. changing system/security/privacy settings;
4. installing, uninstalling, downloading, or running unknown executables;
5. entering, revealing, copying, saving, or transmitting passwords, API keys, tokens, private keys, seed phrases, cookies, or MFA codes;
6. actions affecting third-party accounts, production systems, or external services;
7. anything the user describes as irreversible, sensitive, high-value, or regulated.

If a requested operation is ambiguous, ask a concise clarifying question before acting. For minor reversible UI choices, choose a reasonable default and report it.

## Capability check

At the start of a local-operation task:

1. Identify the desired end state.
2. Check which local-control tools are actually available.
3. If no suitable local-control tools are available, say so plainly and offer to help install or design the MCP server. Do **not** pretend to see or control the desktop.
4. Prefer read-only observation first: list apps/windows, inspect accessibility tree, screenshot, OCR.
5. Only then perform the smallest safe action.

Expected MCP namespace/tool family is described in [tool-contract.md](references/tool-contract.md). The exact names may differ; map available tools by semantics, not by name alone.

## Operating loop

Use this loop for every GUI task:

```text
Goal → Observe → Plan next atomic action → Act → Verify → Continue or stop
```

### 1. Goal

Restate the target in operational terms:

- Which app/window?
- What final visible state or artifact proves success?
- What inputs are needed?
- Which actions require confirmation?

### 2. Observe

Prefer reliable state sources in this order:

1. accessibility tree / UI automation element tree;
2. focused window title and process metadata;
3. screenshot with OCR;
4. image-only screenshot reasoning;
5. coordinates as a last resort.

### 3. Plan next atomic action

Choose one small action that can be verified immediately, such as:

- focus a window;
- press one shortcut;
- click one identified button;
- type one known string;
- wait for one expected UI state.

Avoid long blind macro sequences. If an action would be hard to undo, ask first.

### 4. Act

Prefer stable operations:

- keyboard shortcuts over coordinates;
- accessibility element invocation over mouse clicks;
- window handles/process IDs over window-title guesses;
- paste/type text only into the verified focused field.

When typing sensitive content, stop and ask the user to enter it manually unless the user explicitly provided non-sensitive test data.

### 5. Verify

After each action, observe again and compare with the expected state. If state did not change as expected, do not repeat blindly; diagnose why.

### 6. Stop

Stop when the goal is met, blocked by a user-only decision, or the safety policy requires confirmation.

## Tool-use preferences

- Prefer `window_list` / `window_focus` before app-specific work.
- Prefer `inspect_ui` / accessibility queries before screenshots when available.
- Prefer `screenshot` before coordinate clicking.
- Prefer `hotkey` for standard app commands: save, open, find, copy, paste, undo.
- Use `input_scroll` for small, bounded scrolling after verifying the target window or region.
- Use `wait_for` rather than fixed sleeps when possible.
- Use coordinates only after anchoring them to a current screenshot and explaining what will be clicked.
- Never assume the screen stayed the same after a delay, app launch, modal, notification, or user interaction.

## Failure handling

If the UI does not match expectations:

1. take a fresh observation;
2. check whether a modal, permission prompt, loading state, or focus change occurred;
3. try a different reliable control method;
4. if still blocked, explain what is visible and ask the user for input.

Do not spam clicks or keystrokes.

## Output style

While operating:

- keep user-facing narration brief;
- report meaningful state changes, blockers, or confirmations needed;
- do not narrate every routine observation;
- final response should state what was completed, what was verified, and any remaining manual steps.

## References

- [Architecture](references/architecture.md)
- [Tool contract](references/tool-contract.md)
- [Safety policy](references/safety-policy.md)
- [Operation playbook](references/operation-playbook.md)
- [Example MCP config](examples/local-operator.mcp.json)
- [Session prompt example](examples/session-prompt.md)
- [Doctor / self-test](examples/doctor.md)

# Local Operator Doctor / Self-Test

Use this when you want to know whether the local operator runtime is usable before connecting it to Claude Code.

## 1. Dependency-light self-test

This uses the mock backend and does not require `pytest` or a real desktop:

```bash
cd E:/code/local-operator-mcp
python -m local_operator_mcp.server --self-test
```

Pass criteria:

- JSON output has `"ok": true`.
- Summary says all checks passed.
- Failed checks, if any, include a readable message.

## 2. Capability checks

Read-only mock policy:

```bash
python -m local_operator_mcp.server --backend mock --check
```

Control mock policy:

```bash
python -m local_operator_mcp.server --backend mock --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

Pass criteria:

- Read-only output lists observation tools and marks control tools disabled.
- Control output lists `input_scroll`, `wait_for`, and `action_history`.
- Control output still reports `ui_invoke` as future work.

## 3. Full tests

After installing test dependencies:

```bash
python -m pytest
```

If `pytest` is missing:

```bash
python -m pip install -e ".[test]"
```

If pip reports a hash/cache mismatch, retry with fresh downloads:

```bash
python -m pip install --no-cache-dir -e ".[windows,test]"
```

## 4. Real Windows check

Only run this on an authorized local machine:

```bash
python -m local_operator_mcp.server --backend windows --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

Then connect the MCP server in Claude Code and start with the capability-only prompt from `session-prompt.md`.

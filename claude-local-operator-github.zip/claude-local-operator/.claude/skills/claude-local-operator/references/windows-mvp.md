# Windows MVP Implementation Notes

These notes are for the future `local-operator-mcp` server on Windows.

## Recommended stack

Start with Python because it is fast to iterate:

- `mcp` Python package for the MCP server;
- `pywin32` or `ctypes` for window enumeration/focus;
- `Pillow` or Windows Graphics Capture for screenshots;
- `pyautogui` only for fallback click/type/hotkey operations;
- optional `pywinauto` for UI Automation accessibility trees;
- optional OCR via Windows OCR APIs or Tesseract.

## Window enumeration

Use Win32 APIs:

- `EnumWindows`
- `IsWindowVisible`
- `GetWindowTextW`
- `GetWindowThreadProcessId`
- `GetWindowRect`
- `GetForegroundWindow`

Return stable handles as opaque `window_id` strings. Do not expose raw handles as user-facing instructions.

## Focusing windows

Use cautious focus logic:

- verify the handle still exists;
- restore if minimized;
- bring to foreground;
- observe again and verify it is focused.

If focus fails because Windows blocks foreground changes, ask the user to click the app or use an approved fallback like `Alt+Tab` only with confirmation.

## Screenshots

Capture either:

- full screen;
- active window bounds;
- specified window rectangle.

Always return dimensions so coordinate clicks can be bounded.

Avoid capturing sensitive windows by policy, for example:

- password managers;
- banking/crypto apps;
- private-key tools;
- system security dialogs.

## Input events

Input tools should be disabled by default until policy enables them.

Suggested environment flag:

```text
LOCAL_OPERATOR_ENABLE_INPUT=true
```

Even when enabled, block:

- `Alt+F4` unless confirmed;
- `Shift+Delete`;
- `Ctrl+Alt+Del`;
- `Win+R` unless confirmed;
- unknown global shortcuts;
- rapid repeated clicks/keystrokes.

## Policy file shape

A future `policy.yaml` might look like:

```yaml
apps:
  allow:
    - notepad.exe
    - code.exe
    - chrome.exe
  deny:
    - 1password.exe
    - bitwarden.exe
    - keepassxc.exe
input:
  enabled: false
  max_events_per_minute: 60
confirm:
  always:
    - file_write
    - submit_form
    - external_send
    - install_software
screenshots:
  redact_titles_matching:
    - password
    - token
    - secret
```

## Testing strategy

Use fake windows/mocked backends first. Then run real tests only against safe apps like Notepad.

Core tests:

1. window list returns at least one visible window;
2. focused window matches OS foreground window;
3. screenshot dimensions are positive;
4. input tools refuse when disabled;
5. dangerous shortcuts require confirmation;
6. stale window IDs produce recoverable errors.

# Local Operator Tool Contract

The exact MCP tool names can differ, but a useful local operator server should expose tools with these semantics.

## Observation tools

### `local_operator.app_list`

List running applications and known launchable applications.

Returns:

```json
{
  "running": [{"pid": 1234, "name": "Code.exe", "title": "Visual Studio Code"}],
  "launchable": [{"id": "notepad", "name": "Notepad"}]
}
```

### `local_operator.window_list`

List top-level windows.

Arguments:

```json
{"include_minimized": true}
```

Returns:

```json
{
  "windows": [
    {"window_id": "w1", "pid": 1234, "app": "Code", "title": "main.py - VS Code", "focused": true, "bounds": {"x": 0, "y": 0, "width": 1200, "height": 800}}
  ]
}
```

### `local_operator.inspect_ui`

Return accessibility/UI tree for a window or focused app.

Arguments:

```json
{"window_id": "w1", "max_depth": 6}
```

Return element IDs that can be invoked directly when possible.

### `local_operator.screenshot`

Capture current screen or window.

Arguments:

```json
{"target": "screen|focused_window|window_id", "window_id": "w1", "include_cursor": false}
```

Returns an image reference or base64 payload plus dimensions.

### `local_operator.ocr`

Extract text from screenshot/window region.

Arguments:

```json
{"target": "focused_window", "region": {"x": 0, "y": 0, "width": 500, "height": 300}}
```

## Action tools

### `local_operator.app_launch`

Launch an allowed application.

Arguments:

```json
{"app_id": "notepad", "args": []}
```

Safety: validate against app allowlist.

### `local_operator.window_focus`

Focus a window.

Arguments:

```json
{"window_id": "w1"}
```

### `local_operator.ui_invoke`

Invoke a known accessibility element such as a button or menu item.

Arguments:

```json
{"element_id": "e42", "action": "invoke|focus|expand|select"}
```

Prefer this over coordinate clicks.

### `local_operator.input_hotkey`

Press a key combination.

Arguments:

```json
{"keys": ["CTRL", "S"]}
```

Safety: block dangerous global shortcuts unless confirmed.

### `local_operator.input_type_text`

Type or paste text into the currently focused field.

Arguments:

```json
{"text": "hello", "method": "paste|type"}
```

Safety: require verified focus. Never type secrets unless the user explicitly provided safe test data.

### `local_operator.input_click`

Click a coordinate in a window/screen.

Arguments:

```json
{"target": "window_id", "window_id": "w1", "x": 200, "y": 300, "button": "left", "clicks": 1}
```

Safety: only use after a fresh screenshot/inspection anchors the target.

### `local_operator.input_scroll`

Scroll in the focused window or specified region.

Implemented in the current `local-operator-mcp` MVP as `input_scroll`.

Arguments:

```json
{"delta_y": -600, "delta_x": 0}
```

### `local_operator.wait_for`

Wait until a condition is true.

Implemented in the current `local-operator-mcp` MVP as `wait_for` for window-title/window-exists conditions.

Arguments:

```json
{"condition": {"type": "window_title_contains", "text": "Saved"}, "timeout_ms": 10000}
```

Prefer this over fixed sleeps.

## Administrative tools

### `local_operator.get_policy`

Return current allowlists, denied apps/actions, confirmation requirements, and logging location.

### `local_operator.request_confirmation`

Ask the human to approve a sensitive action. Some harnesses provide native confirmation UI; if so, use that instead.

## Tool result standards

Every action result should include:

```json
{
  "ok": true,
  "action_id": "act_123",
  "summary": "Focused Notepad",
  "post_state_hint": "window_id=w2 focused"
}
```

Errors should be explicit and recoverable:

```json
{
  "ok": false,
  "error_code": "WINDOW_NOT_FOUND",
  "message": "Window w1 no longer exists. Call window_list again."
}
```

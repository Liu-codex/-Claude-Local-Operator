# MCP Server Roadmap

This roadmap turns the skill into a working local operator system.

## Phase 0 — Dry-run tool server

Goal: prove Claude can discover and call local-operator tools without touching the desktop.

- expose `get_policy`, `window_list`, and `screenshot` as mocked or read-only tools;
- return deterministic sample data;
- validate Claude follows the observe-before-act loop;
- verify sensitive actions trigger confirmation.

## Phase 1 — Read-only desktop observation

Goal: let Claude see local app state safely.

Windows MVP:

- enumerate top-level windows with Win32 APIs;
- get focused window title/process;
- capture screenshot of focused window;
- optionally OCR screenshot text;
- never send input events yet.

Acceptance test:

> User asks: "What app is currently focused?" Claude lists windows, identifies the focused app, and reports it without acting.

## Phase 2 — Reversible input actions

Goal: enable low-risk actions with verification.

Add:

- focus a window by handle; **implemented in `local-operator-mcp` MVP**
- send hotkeys from an allowlist; **implemented with dangerous-shortcut blocking**
- type non-sensitive text into a verified focused field; **implemented with secret-looking text and length guards**
- click only within a currently observed window bounds; **implemented when `window_id` is supplied**
- bounded scrolling; **implemented as `input_scroll`**
- wait for visible state changes. **implemented as `wait_for` for initial window-title/window-exists conditions**

Guardrails:

- rate limit input events;
- require current window verification;
- block global destructive shortcuts by default;
- require confirmation for file saves, submits, deletes, installs, payments, and external sends.

## Phase 3 — Accessibility-first control

Goal: reduce coordinate dependence.

Add:

- UI Automation tree inspection;
- element IDs;
- invoke/focus/select on accessibility elements;
- menu and button discovery;
- robust stale-element errors.

Acceptance test:

> User asks Claude to open Notepad settings. Claude invokes accessible buttons/menus where possible and verifies every step.

## Phase 4 — App profiles

Goal: make common apps reliable.

Create per-app profiles:

- browser;
- VS Code;
- Notepad;
- Office apps;
- file explorer;
- custom target apps.

Each profile should define:

- safe shortcuts;
- unsafe actions;
- known UI landmarks;
- expected save/close prompts;
- app-specific verification checks.

## Phase 5 — Audit and replay

Goal: make operation trustworthy.

- log every observation/action/result;
- optionally record screenshots with redaction;
- produce a final action transcript;
- add a replay/debug mode for failed workflows.

## Recommended repository split

Keep this skill separate from the runtime server:

```text
.claude/skills/claude-local-operator/     # instructions and policy
local-operator-mcp/                       # actual MCP server implementation
  server.py
  backends/windows.py
  policy.yaml
  tests/
```

The skill can be published first as the safe operating protocol; the MCP server can evolve independently.

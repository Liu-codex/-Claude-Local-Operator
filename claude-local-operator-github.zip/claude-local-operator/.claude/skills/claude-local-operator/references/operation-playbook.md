# Operation Playbook

Use this checklist during local GUI operation.

## Start

1. Confirm the goal and the app.
2. Identify whether any step will require confirmation.
3. List windows/apps or launch the app.
4. Observe the current state.

## If launching an app

1. Use app allowlist launch tool.
2. Wait for window to appear.
3. Focus the correct window.
4. Verify title/process.

## If clicking

1. Prefer accessibility `ui_invoke`.
2. If unavailable, take a screenshot.
3. Identify the target and coordinates relative to the current window.
4. Click once.
5. Observe again.

## If typing

1. Verify the target field is focused.
2. Confirm the text is non-sensitive.
3. Prefer paste for long text, type for short commands if paste is unavailable.
4. Observe field state after input.

## If waiting

Prefer condition-based wait:

- window title contains text;
- element appears/disappears;
- OCR text appears;
- loading spinner gone;
- process/window exists.

Use fixed sleep only as a fallback, then observe.

## If stuck

1. Refresh observation.
2. Check focus and modal dialogs.
3. Use keyboard navigation (`Tab`, `Esc`, `Alt`) cautiously.
4. Explain the mismatch and ask the user if needed.

## Finish

Report:

- completed action;
- evidence seen on screen;
- files or settings changed, if any;
- manual follow-up required, if any.

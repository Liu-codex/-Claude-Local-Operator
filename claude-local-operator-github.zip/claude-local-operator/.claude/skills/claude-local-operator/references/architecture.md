# Architecture

`claude-local-operator` is a skill layer, not the automation runtime.

```text
User request
  ↓
Claude Code skill: claude-local-operator
  ↓
Local MCP server: exposes safe desktop tools
  ↓
Automation adapter: OS / accessibility / screenshot / input APIs
  ↓
Real local applications
```

## Responsibilities

### Skill

- Decide when local GUI operation is appropriate.
- Apply the safety policy.
- Choose a cautious observe-act-verify loop.
- Prefer stable UI automation over blind coordinates.
- Stop for confirmation at sensitive boundaries.

### MCP server

- Expose typed tools with clear, auditable arguments.
- Enforce OS-level safety constraints.
- Limit which apps, paths, hosts, and actions are allowed.
- Return structured observations and errors.
- Log actions for review.

### Automation adapter

Possible implementation layers:

- Windows: UI Automation, Win32 APIs, PowerShell, pywinauto, pyautogui, OCR.
- macOS: Accessibility API, AppleScript/JXA, Quartz screenshots/events.
- Linux: AT-SPI, xdotool/ydotool, wlroots/portal screenshots, OCR.
- Browser-only flows: Playwright or browser MCP is usually better than pixel GUI control.

## Recommended MVP

Start with a conservative Windows MVP:

1. `app.launch`
2. `window.list`
3. `window.focus`
4. `screen.screenshot`
5. `input.hotkey`
6. `input.type_text`
7. `input.click`
8. `wait.for_condition`

Then add:

- accessibility tree inspection;
- OCR;
- app allowlists;
- per-action confirmation;
- session recording/logging;
- rollback helpers where possible.

## Trust boundary

Treat all model-generated actions as untrusted proposals until the MCP server validates them. The MCP server should enforce:

- app allowlist / denylist;
- coordinate bounds;
- path confinement;
- blocked secrets and credential fields;
- rate limits for input events;
- confirmation for destructive or external actions.

The skill reminds Claude to be careful, but the MCP server must provide hard controls.

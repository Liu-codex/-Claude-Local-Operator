# Safety Policy

This skill is for authorized local automation only.

## Default posture

- Observe before acting.
- Prefer reversible actions.
- Ask before destructive, external, sensitive, or high-impact actions.
- Never handle secrets unless the user explicitly instructs and the operation is safe; prefer asking the user to type secrets manually.
- Stop if the visible state contradicts the plan.

## Confirmation required

Ask for explicit confirmation immediately before:

- deleting, overwriting, moving, or mass-editing files;
- sending, submitting, purchasing, publishing, committing, pushing, or deploying;
- changing account, privacy, security, network, firewall, antivirus, or system settings;
- installing software or executing downloaded files;
- entering credentials, tokens, payment details, private keys, MFA codes, or seed phrases;
- interacting with production systems or third-party accounts;
- closing unsaved work or discarding changes.

The confirmation should name the specific action and target, for example:

> I am about to click "Send" in Outlook to email `report.docx` to `alice@example.com`. Proceed?

## Prohibited behavior

Do not:

- operate someone else's machine or account without clear authorization;
- bypass access controls, paywalls, locks, monitoring, or security tools;
- evade detection or hide actions;
- collect or exfiltrate secrets;
- automate spam, abuse, scraping at scale, credential attacks, destructive actions, or denial-of-service;
- keep trying random clicks/keystrokes when state is unknown.

## Sensitive UI handling

If a password manager, banking app, crypto wallet, admin console, or security prompt appears:

1. stop;
2. describe the prompt at a high level;
3. ask the user to take over or confirm the exact safe next step.

Do not read, copy, or type hidden fields or one-time codes.

## Logging

The MCP server should log:

- timestamp;
- tool name;
- sanitized arguments;
- target app/window;
- result summary;
- whether user confirmation was required.

Do not log secrets or full screenshots of sensitive apps unless the user explicitly opted in.

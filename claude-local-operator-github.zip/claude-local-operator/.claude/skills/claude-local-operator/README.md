# Claude Local Operator Skill

A Claude Code skill for safely operating local desktop applications through an authorized local MCP automation server.

## What this is

This is the **skill layer** for a local computer operator:

- when to use GUI automation;
- how to observe, act, and verify;
- what safety boundaries to follow;
- what MCP tools a local automation server should expose.

The matching local MCP runtime now lives at:

```text
E:/code/local-operator-mcp/
```

The skill does not control the desktop by itself. It becomes useful after Claude Code is connected to that MCP server.

## Files

- `SKILL.md` — main skill instructions loaded by Claude.
- `references/architecture.md` — architecture and trust boundary.
- `references/tool-contract.md` — MCP tool API and expected semantics.
- `references/safety-policy.md` — confirmation and prohibition rules.
- `references/operation-playbook.md` — observe/act/verify checklist.
- `references/windows-mvp.md` — Windows implementation notes.
- `references/mcp-server-roadmap.md` — phased roadmap and current status.
- `examples/local-operator.mcp.json` — Claude Code MCP config fragment.
- `examples/session-prompt.md` — prompts for testing the skill.
- `examples/smoke-tests.md` — manual pass/fail smoke tests.

## Runtime status

`local-operator-mcp` currently provides:

Observation:

1. `get_policy`
2. `action_history`
3. `window_list`
4. `focused_window`
5. `screenshot`
6. `wait_for`

Policy-gated control:

1. `window_focus`
2. `app_launch`
3. `input_hotkey`
4. `input_type_text`
5. `input_click`
6. `input_scroll`

Not implemented yet:

- accessibility tree inspection / `ui_invoke`;
- OCR;
- app-specific profiles;
- persistent audit logs across server restarts.

## Quick install / check

From the MCP server folder:

```bash
cd E:/code/local-operator-mcp
python -m pip install -e ".[windows,test]"
```

If pip reports a package hash/cache mismatch, retry with fresh downloads:

```bash
python -m pip install --no-cache-dir -e ".[windows,test]"
```

Dependency-light self-test that does **not** require pytest:

```bash
python -m local_operator_mcp.server --self-test
```

Capability checks:

```bash
python -m local_operator_mcp.server --backend mock --check
python -m local_operator_mcp.server --backend mock --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

Full tests, after pytest is installed:

```bash
python -m pytest
```

## Claude Code MCP config

Use [local-operator.mcp.json](examples/local-operator.mcp.json) as the config fragment. It runs:

```text
python -m local_operator_mcp.server
```

from:

```text
E:/code/local-operator-mcp
```

with the control policy:

```text
E:/code/local-operator-mcp/configs/policy.control.json
```

Control mode is still guarded by the MCP server policy: dangerous shortcuts, secret-looking text, sensitive windows, long pastes, unallowlisted app launches, and rapid input are blocked.

## Safe first prompt

```text
Use claude-local-operator. Tell me what local operator tools are available and what they can do. Do not operate the computer yet.
```

Then, after the capability check passes:

```text
Use claude-local-operator. Open Notepad, type "Claude local operator control test", wait until the focused window title contains Notepad, verify the text is visible, then stop. Do not save or close anything.
```

## Safety reminder

Keep hard safety enforcement in the MCP server, not only in prompts. The skill tells Claude how to behave; the MCP server must still reject unsafe actions.

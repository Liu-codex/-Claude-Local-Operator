from __future__ import annotations

from local_operator_mcp.service import LocalOperatorService

CONTROL_POLICY = "E:/code/local-operator-mcp/configs/policy.control.json"


def test_mock_policy_capabilities() -> None:
    service = LocalOperatorService(backend_name="mock")
    policy = service.get_policy()
    assert policy["mode"] == "read_only"
    assert policy["capabilities"]["backend"] == "mock"
    assert "window_list" in policy["capabilities"]["tools"]
    assert "wait_for" in policy["capabilities"]["tools"]
    assert "open_url" in policy["capabilities"]["disabled_until_future_phase"]
    assert "browser_search" in policy["capabilities"]["disabled_until_future_phase"]


def test_control_policy_capabilities_include_browser_tools() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    policy = service.get_policy()
    assert "open_url" in policy["capabilities"]["tools"]
    assert "browser_search" in policy["capabilities"]["tools"]


def test_mock_window_list() -> None:
    service = LocalOperatorService(backend_name="mock")
    result = service.window_list()
    assert result["backend"] == "mock"
    assert result["windows"]
    assert result["windows"][0]["window_id"].startswith("mock:")


def test_mock_focused_window() -> None:
    service = LocalOperatorService(backend_name="mock")
    result = service.focused_window()
    assert result["window"] is not None
    assert result["window"]["focused"] is True


def test_mock_screenshot() -> None:
    service = LocalOperatorService(backend_name="mock")
    result = service.screenshot(target="focused_window", max_width=640)
    assert result["image"]["mime_type"] in {"image/jpeg", "image/png"}
    assert result["image"]["base64"]
    assert result["image"]["width"] <= 640


def test_readonly_blocks_control() -> None:
    service = LocalOperatorService(backend_name="mock")
    try:
        service.input_type_text("hello")
    except Exception as exc:
        assert "disabled by policy" in str(exc)
    else:
        raise AssertionError("expected read-only policy to block input")


def test_readonly_blocks_browser_actions() -> None:
    service = LocalOperatorService(backend_name="mock")
    for action in (lambda: service.open_url("https://example.com"), lambda: service.browser_search("Claude")):
        try:
            action()
        except Exception as exc:
            assert "disabled by policy" in str(exc)
        else:
            raise AssertionError("expected read-only policy to block browser action")


def test_mock_control_actions() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    windows = service.window_list()["windows"]
    target = windows[1]["window_id"]
    assert service.window_focus(target)["ok"] is True
    assert service.focused_window()["window"]["window_id"] == target
    assert service.app_launch("notepad")["ok"] is True
    assert service.input_hotkey(["CTRL", "A"])["ok"] is True
    assert service.input_type_text("safe test text")["ok"] is True
    assert service.input_click(120, 120, window_id=target)["ok"] is True
    assert service.input_scroll(-600, window_id=target)["ok"] is True
    assert len(service.action_history()["actions"]) >= 6


def test_browser_aliases_launch_allowed_browsers() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    assert service.app_launch("edge")["app_id"] == "msedge.exe"
    assert service.app_launch("msedge")["app_id"] == "msedge.exe"
    assert service.app_launch("chrome")["app_id"] == "chrome.exe"


def test_open_url_uses_browser_directly_and_returns_window() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    result = service.open_url("https://example.com", browser="edge")
    assert result["ok"] is True
    assert result["app_id"] == "msedge.exe"
    assert result["url"] == "https://example.com"
    assert result["window"]["app"] == "msedge.exe"
    actions = service.action_history()["actions"]
    assert actions[-1]["action"] == "open_url"
    assert actions[-1]["details"]["host"] == "example.com"
    assert "url" not in actions[-1]["details"]


def test_browser_search_encodes_query_and_records_one_action() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    result = service.browser_search("Claude local operator", browser="edge", engine="bing")
    assert result["ok"] is True
    assert result["app_id"] == "msedge.exe"
    assert result["url"] == "https://www.bing.com/search?q=Claude+local+operator"
    assert result["window"]["title"].startswith("Claude local operator")
    actions = service.action_history()["actions"]
    assert len(actions) == 1
    assert actions[-1]["action"] == "browser_search"
    assert actions[-1]["details"] == {
        "browser": "edge",
        "app_id": "msedge.exe",
        "engine": "bing",
        "query_chars": len("Claude local operator"),
        "wait": True,
    }


def test_browser_actions_reject_unsafe_urls_and_secret_queries() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    unsafe_urls = [
        "file:///C:/Windows/win.ini",
        "javascript:alert(1)",
        "data:text/html,hello",
        "about:blank",
        "https://example.com/?token=secret",
    ]
    for url in unsafe_urls:
        try:
            service.open_url(url)
        except Exception as exc:
            assert "url" in str(exc).lower() or "secret" in str(exc).lower() or "http" in str(exc).lower()
        else:
            raise AssertionError(f"expected unsafe URL to be blocked: {url}")

    try:
        service.browser_search("sk-secret-token")
    except Exception as exc:
        assert "secret" in str(exc).lower()
    else:
        raise AssertionError("expected secret-looking query to be blocked")


def test_wait_for_focused_window_title() -> None:
    service = LocalOperatorService(backend_name="mock")
    result = service.wait_for({"type": "focused_window_title_contains", "text": "Notepad"}, timeout_ms=200)
    assert result["ok"] is True
    assert result["matched"] is True
    assert result["observation"]["window"]["window_id"] == "mock:notepad"


def test_wait_for_window_app_exists() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    service.open_url("https://example.com", browser="edge")
    result = service.wait_for({"type": "window_app_exists", "app": "msedge.exe"}, timeout_ms=200)
    assert result["ok"] is True
    assert result["matched"] is True
    assert result["observation"]["matching_windows"][0]["app"] == "msedge.exe"


def test_wait_for_timeout_is_recoverable() -> None:
    service = LocalOperatorService(backend_name="mock")
    result = service.wait_for(
        {"type": "window_title_contains", "text": "definitely-not-present"},
        timeout_ms=120,
        poll_ms=50,
    )
    assert result["ok"] is True
    assert result["matched"] is False
    assert "Timed out" in result["message"]


def test_secret_text_blocked() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    try:
        service.input_type_text("sk-secret-token")
    except Exception as exc:
        assert "secret" in str(exc).lower()
    else:
        raise AssertionError("expected secret-looking text to be blocked")


def test_dangerous_hotkey_blocked_with_aliases() -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=CONTROL_POLICY)
    try:
        service.input_hotkey(["control", "alt", "del"])
    except Exception as exc:
        assert "blocked" in str(exc).lower()
    else:
        raise AssertionError("expected dangerous hotkey to be blocked")

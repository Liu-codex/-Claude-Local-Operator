# Manual smoke tests

## Mock backend

```bash
cd E:/code/local-operator-mcp
python -m local_operator_mcp.server --backend mock --check
pytest
python -m local_operator_mcp.server --self-test
```

Expected:

- mock backend reports read-only capabilities;
- pytest passes;
- self-test reports all checks passed, including browser actions.

## Control mock

```bash
cd E:/code/local-operator-mcp
python -m local_operator_mcp.server --backend mock --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

Expected:

- backend is `mock`;
- control tools include `open_url` and `browser_search`;
- `apps.allow` includes `msedge.exe` and `chrome.exe`.

## Real Windows backend

```bash
cd E:/code/local-operator-mcp
python -m pip install -e ".[windows,test]"
python -m local_operator_mcp.server --backend windows --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

Expected:

- policy JSON prints;
- backend is `windows`;
- control tools are listed.

## Real Edge browser smoke

After the MCP config is loaded in Claude Code control mode, ask:

```text
Use claude-local-operator. Search for "Claude" in Edge using the browser_search tool, verify an Edge window appears, then stop.
```

Expected:

- Claude uses one high-level `browser_search` call instead of `window_focus`, `input_hotkey`, `input_type_text`, and Enter;
- Edge opens or reuses an existing window;
- the returned window app is `msedge.exe` when available;
- the search URL is an HTTP(S) search-engine URL.

## Safety smoke

Ask Claude to try a blocked URL:

```text
Use claude-local-operator. Try to open file:///C:/Windows/win.ini and report whether it is blocked.
```

Expected:

- `open_url` returns a policy-blocked error;
- no browser navigation occurs.

## Claude prompt for observation only

After adding the MCP config:

```text
Use claude-local-operator. Call get_policy and window_list. Tell me what window is focused. Do not click or type.
```

Expected:

- Claude calls read-only tools only;
- no app state changes;
- focused window is reported.

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Literal

from .models import PolicyBlockedError, ToolError
from .selftest import run_self_test
from .service import LocalOperatorService

_service = LocalOperatorService()


def get_policy() -> dict:
    """Return the active local-operator safety policy and available capabilities."""
    return _service.get_policy()


def action_history(limit: int = 20) -> dict:
    """Return recent local-operator action audit entries for this server process."""
    return _service.action_history(limit=limit)


def window_list(include_minimized: bool = True, limit: int = 50) -> dict:
    """List visible desktop windows. This does not focus or modify windows."""
    return _service.window_list(include_minimized=include_minimized, limit=limit)


def focused_window() -> dict:
    """Return the currently focused desktop window, if one is available."""
    return _service.focused_window()


def screenshot(
    target: Literal["screen", "focused_window", "window_id"] = "focused_window",
    window_id: str | None = None,
    max_width: int = 1280,
    image_format: Literal["jpeg", "png"] = "jpeg",
) -> dict:
    """Capture a screenshot for observation. Use focused_window or window_id before coordinate-based reasoning."""
    return _call_tool(
        _service.screenshot,
        target=target,
        window_id=window_id,
        max_width=max_width,
        image_format=image_format,
    )


def wait_for(condition: dict[str, Any], timeout_ms: int = 10000, poll_ms: int = 250) -> dict:
    """Wait until a supported UI condition is true. Read-only; does not click or type."""
    return _call_tool(_service.wait_for, condition=condition, timeout_ms=timeout_ms, poll_ms=poll_ms)


def window_focus(window_id: str) -> dict:
    """Focus a known window. Requires control mode in policy."""
    return _call_tool(_service.window_focus, window_id=window_id)


def app_launch(app_id: str, args: list[str] | None = None) -> dict:
    """Launch an allowed application alias or allowlisted executable. Requires control mode in policy."""
    return _call_tool(_service.app_launch, app_id=app_id, args=args or [])


def open_url(url: str, browser: str = "edge", new_window: bool = False, wait: bool = True) -> dict:
    """Open an HTTP(S) URL in an allowed browser. Requires control mode in policy."""
    return _call_tool(_service.open_url, url=url, browser=browser, new_window=new_window, wait=wait)


def browser_search(query: str, browser: str = "edge", engine: str = "bing", wait: bool = True) -> dict:
    """Search the web in an allowed browser without keyboarding into the page. Requires control mode in policy."""
    return _call_tool(_service.browser_search, query=query, browser=browser, engine=engine, wait=wait)


def input_hotkey(keys: list[str]) -> dict:
    """Send a keyboard shortcut to the focused window. Requires control mode in policy."""
    return _call_tool(_service.input_hotkey, keys=keys)


def input_type_text(text: str, method: Literal["paste", "type"] = "paste") -> dict:
    """Type or paste non-sensitive text into the verified focused field/window. Requires control mode in policy."""
    return _call_tool(_service.input_type_text, text=text, method=method)


def input_click(
    x: int,
    y: int,
    button: Literal["left", "right", "middle"] = "left",
    clicks: int = 1,
    window_id: str | None = None,
) -> dict:
    """Click screen coordinates, optionally bounded to a known window. Requires control mode in policy."""
    return _call_tool(_service.input_click, x=x, y=y, button=button, clicks=clicks, window_id=window_id)


def input_scroll(delta_y: int, delta_x: int = 0, window_id: str | None = None) -> dict:
    """Scroll the focused window or a known window. Requires control mode in policy."""
    return _call_tool(_service.input_scroll, delta_y=delta_y, delta_x=delta_x, window_id=window_id)


def create_mcp_app():
    """Create the MCP app lazily so --check works before the mcp package is installed."""
    from mcp.server.fastmcp import FastMCP

    app = FastMCP("local-operator-mcp")
    app.tool()(get_policy)
    app.tool()(action_history)
    app.tool()(window_list)
    app.tool()(focused_window)
    app.tool()(screenshot)
    app.tool()(wait_for)
    app.tool()(window_focus)
    app.tool()(app_launch)
    app.tool()(open_url)
    app.tool()(browser_search)
    app.tool()(input_hotkey)
    app.tool()(input_type_text)
    app.tool()(input_click)
    app.tool()(input_scroll)
    return app


def _call_tool(fn, **kwargs) -> dict:
    try:
        return fn(**kwargs)
    except PolicyBlockedError as exc:
        return _error_payload(exc)
    except ToolError as exc:
        return _error_payload(exc)


def _error_payload(exc: ToolError) -> dict:
    return {
        "ok": False,
        "error_code": exc.code,
        "message": str(exc),
        "details": exc.details,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Local Operator MCP server")
    parser.add_argument("--backend", choices=["auto", "mock", "windows"], default=None)
    parser.add_argument("--policy", default=None, help="Path to YAML/JSON policy file")
    parser.add_argument("--check", action="store_true", help="Print backend/policy capabilities and exit")
    parser.add_argument("--self-test", action="store_true", help="Run dependency-light mock self-tests and exit")
    args = parser.parse_args()

    global _service
    _service = LocalOperatorService(backend_name=args.backend, policy_path=args.policy)

    if args.self_test:
        json.dump(run_self_test(control_policy=args.policy or "E:/code/local-operator-mcp/configs/policy.control.json"), sys.stdout, indent=2)
        sys.stdout.write("\n")
        return

    if args.check:
        json.dump(_service.get_policy(), sys.stdout, indent=2)
        sys.stdout.write("\n")
        return

    create_mcp_app().run()


if __name__ == "__main__":
    main()

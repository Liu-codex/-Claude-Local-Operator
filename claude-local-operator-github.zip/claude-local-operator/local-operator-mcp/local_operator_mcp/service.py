from __future__ import annotations

import time
from typing import Any, Literal
from urllib.parse import urlencode, urlparse

from .backends import create_backend
from .backends.base import DesktopBackend
from .models import Policy, PolicyBlockedError, WindowInfo
from .policy import load_policy

_BUILTIN_SAFE_APP_IDS = {
    "notepad": "notepad.exe",
    "calc": "calc.exe",
    "calculator": "calc.exe",
}

_BROWSER_APP_IDS = {
    "edge": "msedge.exe",
    "msedge": "msedge.exe",
    "microsoft_edge": "msedge.exe",
    "chrome": "chrome.exe",
    "google_chrome": "chrome.exe",
}

_SAFE_APP_IDS = {**_BUILTIN_SAFE_APP_IDS, **_BROWSER_APP_IDS}

_SEARCH_ENGINES = {
    "bing": "https://www.bing.com/search",
    "google": "https://www.google.com/search",
    "duckduckgo": "https://duckduckgo.com/",
}

_DANGEROUS_HOTKEYS = {
    frozenset(("ALT", "F4")),
    frozenset(("SHIFT", "DELETE")),
    frozenset(("CTRL", "W")),
    frozenset(("CTRL", "Q")),
    frozenset(("CTRL", "ALT", "DELETE")),
    frozenset(("WIN", "R")),
}

_KEY_ALIASES = {
    "CONTROL": "CTRL",
    "WINDOWS": "WIN",
    "DEL": "DELETE",
}


class LocalOperatorService:
    def __init__(self, backend_name: str | None = None, policy_path: str | None = None) -> None:
        self.policy: Policy = load_policy(policy_path)
        self.backend: DesktopBackend = create_backend(backend_name or self.policy.backend)
        self.policy.backend = self.backend.name
        self._action_log: list[dict[str, Any]] = []
        self._action_seq = 0
        self._input_event_times: list[float] = []

    def get_policy(self) -> dict:
        control_enabled = self._control_enabled()
        tools = ["get_policy", "action_history", "window_list", "focused_window", "screenshot", "wait_for"]
        disabled = ["ui_invoke"]
        if control_enabled:
            tools.extend(
                [
                    "window_focus",
                    "app_launch",
                    "open_url",
                    "browser_search",
                    "input_hotkey",
                    "input_type_text",
                    "input_click",
                    "input_scroll",
                ]
            )
        else:
            disabled.extend(
                [
                    "app_launch",
                    "open_url",
                    "browser_search",
                    "window_focus",
                    "input_hotkey",
                    "input_type_text",
                    "input_click",
                    "input_scroll",
                ]
            )
        payload = self.policy.model_dump()
        payload["capabilities"] = {
            "backend": self.backend.name,
            "read_only": not control_enabled,
            "control_enabled": control_enabled,
            "tools": tools,
            "disabled_until_future_phase": disabled,
            "recent_action_count": len(self._action_log),
        }
        return payload

    def action_history(self, limit: int = 20) -> dict:
        limit = max(1, min(limit, 100))
        return {
            "backend": self.backend.name,
            "actions": self._action_log[-limit:],
        }

    def window_list(self, include_minimized: bool = True, limit: int = 50) -> dict:
        windows = self.backend.list_windows(include_minimized=include_minimized, limit=limit)
        return {
            "backend": self.backend.name,
            "windows": [self._sanitize_window(window).model_dump() for window in windows],
        }

    def focused_window(self) -> dict:
        window = self.backend.focused_window()
        return {
            "backend": self.backend.name,
            "window": self._sanitize_window(window).model_dump() if window else None,
        }

    def screenshot(
        self,
        target: Literal["screen", "focused_window", "window_id"] = "focused_window",
        window_id: str | None = None,
        max_width: int = 1280,
        image_format: Literal["jpeg", "png"] = "jpeg",
    ) -> dict:
        target_window = self._target_window(target, window_id)
        if target_window is not None:
            self._check_screenshot_allowed(target_window)
        result = self.backend.screenshot(
            target=target,
            window_id=window_id,
            max_width=max_width,
            image_format=image_format,
        )
        return result.model_dump()

    def wait_for(self, condition: dict[str, Any], timeout_ms: int = 10000, poll_ms: int = 250) -> dict:
        timeout_ms = max(100, min(int(timeout_ms), 60000))
        poll_ms = max(50, min(int(poll_ms), 2000))
        started = time.monotonic()
        deadline = started + timeout_ms / 1000
        observation: dict[str, Any] = {}

        while True:
            matched, observation = self._evaluate_condition(condition)
            elapsed_ms = int((time.monotonic() - started) * 1000)
            if matched:
                return {
                    "ok": True,
                    "matched": True,
                    "elapsed_ms": elapsed_ms,
                    "condition": condition,
                    "observation": observation,
                }
            if time.monotonic() >= deadline:
                return {
                    "ok": True,
                    "matched": False,
                    "elapsed_ms": elapsed_ms,
                    "condition": condition,
                    "observation": observation,
                    "message": "Timed out waiting for condition.",
                }
            time.sleep(poll_ms / 1000)

    def window_focus(self, window_id: str) -> dict:
        self._require_control("window_focus")
        self._check_rate_limit("window_focus")
        window = self._window_by_id(window_id)
        self._check_window_action_allowed(window, "window_focus")
        result = self.backend.window_focus(window_id)
        return self._record_action("window_focus", {"window_id": window_id}, result)

    def app_launch(self, app_id: str, args: list[str] | None = None) -> dict:
        self._require_control("app_launch")
        self._check_rate_limit("app_launch")
        command = self._resolve_app_id(app_id)
        result = self.backend.app_launch(command, args or [])
        return self._record_action("app_launch", {"app_id": app_id, "resolved_app_id": command, "args": args or []}, result)

    def open_url(
        self,
        url: str,
        browser: str = "edge",
        new_window: bool = False,
        wait: bool = True,
    ) -> dict:
        self._require_control("open_url")
        self._check_rate_limit("open_url")
        normalized_url = self._validate_url(url)
        app_id = self._resolve_browser_app(browser)
        parsed = urlparse(normalized_url)
        args = self._browser_launch_args(normalized_url, new_window=new_window)
        return self._launch_browser_url(
            action="open_url",
            app_id=app_id,
            browser=browser,
            args=args,
            url=normalized_url,
            wait=wait,
            audit_details={
                "browser": browser,
                "app_id": app_id,
                "scheme": parsed.scheme,
                "host": parsed.netloc,
                "new_window": bool(new_window),
                "wait": bool(wait),
            },
        )

    def browser_search(
        self,
        query: str,
        browser: str = "edge",
        engine: str = "bing",
        wait: bool = True,
    ) -> dict:
        self._require_control("browser_search")
        self._check_rate_limit("browser_search")
        search_url = self._search_url(query, engine=engine)
        app_id = self._resolve_browser_app(browser)
        return self._launch_browser_url(
            action="browser_search",
            app_id=app_id,
            browser=browser,
            args=[search_url],
            url=search_url,
            wait=wait,
            audit_details={
                "browser": browser,
                "app_id": app_id,
                "engine": engine.lower(),
                "query_chars": len(query),
                "wait": bool(wait),
            },
        )

    def input_hotkey(self, keys: list[str]) -> dict:
        self._require_control("input_hotkey")
        self._check_rate_limit("input_hotkey")
        normalized = tuple(self._normalize_key(key) for key in keys)
        if frozenset(normalized) in _DANGEROUS_HOTKEYS:
            raise PolicyBlockedError(
                f"Hotkey {keys} requires a future explicit confirmation flow and is blocked for now.",
                details={"keys": keys, "normalized": normalized},
            )
        result = self.backend.input_hotkey(keys)
        return self._record_action("input_hotkey", {"keys": normalized}, result)

    def input_type_text(self, text: str, method: Literal["paste", "type"] = "paste") -> dict:
        self._require_control("input_type_text")
        self._check_rate_limit("input_type_text")
        if self._looks_sensitive(text):
            raise PolicyBlockedError("Refusing to type text that looks like a secret or credential.")
        max_chars = int(self.policy.input.get("max_text_chars", 5000))
        if len(text) > max_chars:
            raise PolicyBlockedError(
                f"Refusing to type {len(text)} characters; policy max_text_chars is {max_chars}.",
                details={"characters": len(text), "max_text_chars": max_chars},
            )
        focused = self.backend.focused_window()
        if focused is not None:
            self._check_window_action_allowed(focused, "input_type_text")
        result = self.backend.input_type_text(text, method=method)
        return self._record_action("input_type_text", {"method": method, "characters": len(text)}, result)

    def input_click(
        self,
        x: int,
        y: int,
        button: Literal["left", "right", "middle"] = "left",
        clicks: int = 1,
        window_id: str | None = None,
    ) -> dict:
        self._require_control("input_click")
        self._check_rate_limit("input_click")
        if clicks < 1 or clicks > 2:
            raise PolicyBlockedError("Only one or two clicks are allowed per tool call.")
        if window_id:
            window = self._window_by_id(window_id)
            self._check_window_action_allowed(window, "input_click")
            if window.bounds and not self._point_in_window(x, y, window):
                raise PolicyBlockedError(
                    "Click coordinate is outside the declared target window bounds.",
                    details={"x": x, "y": y, "window_id": window_id, "bounds": window.bounds.model_dump()},
                )
        result = self.backend.input_click(x=x, y=y, button=button, clicks=clicks, window_id=window_id)
        return self._record_action(
            "input_click",
            {"x": x, "y": y, "button": button, "clicks": clicks, "window_id": window_id},
            result,
        )

    def input_scroll(self, delta_y: int, delta_x: int = 0, window_id: str | None = None) -> dict:
        self._require_control("input_scroll")
        self._check_rate_limit("input_scroll")
        max_delta = int(self.policy.input.get("max_scroll_delta", 1200))
        delta_y = self._clamp_delta(delta_y, max_delta)
        delta_x = self._clamp_delta(delta_x, max_delta)
        if delta_y == 0 and delta_x == 0:
            raise PolicyBlockedError("Scroll delta must be non-zero after policy clamping.")
        if window_id:
            window = self._window_by_id(window_id)
            self._check_window_action_allowed(window, "input_scroll")
        result = self.backend.input_scroll(delta_y=delta_y, delta_x=delta_x, window_id=window_id)
        return self._record_action(
            "input_scroll",
            {"delta_y": delta_y, "delta_x": delta_x, "window_id": window_id},
            result,
        )

    def _target_window(self, target: str, window_id: str | None) -> WindowInfo | None:
        if target == "screen":
            return None
        if target == "focused_window":
            return self.backend.focused_window()
        if target == "window_id":
            return self._window_by_id(window_id)
        return None

    def _window_by_id(self, window_id: str | None) -> WindowInfo:
        for window in self.backend.list_windows(include_minimized=True, limit=200):
            if window.window_id == window_id:
                return window
        raise PolicyBlockedError(f"Unknown or stale window_id: {window_id}")

    def _sanitize_window(self, window: WindowInfo) -> WindowInfo:
        return WindowInfo.model_validate(window.model_dump())

    def _check_screenshot_allowed(self, window: WindowInfo) -> None:
        self._check_window_action_allowed(window, "screenshot")

    def _check_window_action_allowed(self, window: WindowInfo, action: str) -> None:
        deny = [item.lower() for item in self.policy.apps.get("deny", [])]
        haystack = " ".join(filter(None, [window.app, window.title, window.class_name])).lower()
        if any(pattern and pattern in haystack for pattern in deny):
            raise PolicyBlockedError(
                f"{action} blocked by policy for sensitive window: {window.title!r}",
                details={"window_id": window.window_id, "app": window.app, "action": action},
            )

    def _resolve_app_id(self, app_id: str) -> str:
        allow = self.policy.apps.get("allow", [])
        normalized = app_id.lower()
        allow_lower = {item.lower() for item in allow}
        if normalized in _BUILTIN_SAFE_APP_IDS:
            return _BUILTIN_SAFE_APP_IDS[normalized]
        if normalized in _BROWSER_APP_IDS:
            resolved = _BROWSER_APP_IDS[normalized]
            if resolved.lower() in allow_lower:
                return resolved
            raise PolicyBlockedError(
                f"Browser launch is restricted. Add {resolved!r} to policy apps.allow to enable alias {app_id!r}.",
                details={"app_id": app_id, "resolved_app_id": resolved, "policy_allowlist": allow},
            )
        if app_id in allow:
            return app_id
        raise PolicyBlockedError(
            f"App launch is restricted. Allowed aliases: {sorted(_SAFE_APP_IDS)}; policy allowlist: {allow}",
            details={"app_id": app_id},
        )

    def _resolve_browser_app(self, browser: str | None) -> str:
        browser_name = (browser or "edge").lower()
        if browser_name not in _BROWSER_APP_IDS and browser_name not in {item.lower() for item in self.policy.apps.get("allow", [])}:
            raise PolicyBlockedError(
                "Browser is restricted to known safe browser aliases or policy-allowlisted browser executables.",
                details={"browser": browser, "allowed_aliases": sorted(_BROWSER_APP_IDS)},
            )
        app_id = self._resolve_app_id(browser_name if browser_name in _BROWSER_APP_IDS else browser or "edge")
        if app_id.lower() not in {"msedge.exe", "chrome.exe"}:
            raise PolicyBlockedError(
                "open_url and browser_search only support Edge and Chrome executables for now.",
                details={"browser": browser, "resolved_app_id": app_id},
            )
        return app_id

    def _validate_url(self, url: str) -> str:
        candidate = str(url).strip()
        if not candidate:
            raise PolicyBlockedError("URL must not be empty.")
        if self._looks_sensitive(candidate):
            raise PolicyBlockedError("Refusing to open a URL that looks like it contains a secret or credential.")
        if "://" not in candidate and "." in candidate and not any(char.isspace() for char in candidate):
            candidate = f"https://{candidate}"
        parsed = urlparse(candidate)
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
            raise PolicyBlockedError(
                "Only http:// and https:// URLs with a hostname are allowed.",
                details={"url_scheme": parsed.scheme or None},
            )
        return parsed.geturl()

    def _search_url(self, query: str, engine: str = "bing") -> str:
        normalized_query = str(query).strip()
        if not normalized_query:
            raise PolicyBlockedError("Search query must not be empty.")
        if self._looks_sensitive(normalized_query):
            raise PolicyBlockedError("Refusing to search text that looks like a secret or credential.")
        max_chars = min(int(self.policy.input.get("max_text_chars", 5000)), 1000)
        if len(normalized_query) > max_chars:
            raise PolicyBlockedError(
                f"Refusing to search {len(normalized_query)} characters; browser search max is {max_chars}.",
                details={"characters": len(normalized_query), "max_chars": max_chars},
            )
        engine_name = engine.lower()
        base_url = _SEARCH_ENGINES.get(engine_name)
        if not base_url:
            raise PolicyBlockedError(
                "Unsupported search engine.",
                details={"engine": engine, "supported_engines": sorted(_SEARCH_ENGINES)},
            )
        return f"{base_url}?{urlencode({'q': normalized_query})}"

    def _browser_launch_args(self, url: str, new_window: bool = False) -> list[str]:
        if new_window:
            return ["--new-window", url]
        return [url]

    def _launch_browser_url(
        self,
        action: str,
        app_id: str,
        browser: str,
        args: list[str],
        url: str,
        wait: bool,
        audit_details: dict[str, Any],
    ) -> dict:
        started = time.monotonic()
        launch_result = self.backend.app_launch(app_id, args)
        window = self._wait_for_app_window(app_id) if wait else None
        payload: dict[str, Any] = {
            "ok": bool(launch_result.get("ok", True)),
            "browser": browser,
            "app_id": app_id,
            "url": url,
            "pid": launch_result.get("pid"),
            "window": self._sanitize_window(window).model_dump() if window else None,
            "elapsed_ms": int((time.monotonic() - started) * 1000),
        }
        return self._record_action(action, audit_details, payload)

    def _wait_for_app_window(self, app_id: str, timeout_ms: int = 4000, poll_ms: int = 100) -> WindowInfo | None:
        started = time.monotonic()
        deadline = started + timeout_ms / 1000
        app_name = app_id.lower()
        latest_match: WindowInfo | None = None
        while True:
            windows = self.backend.list_windows(include_minimized=True, limit=200)
            matching = [window for window in windows if (window.app or "").lower() == app_name]
            if matching:
                latest_match = next((window for window in matching if window.focused), matching[0])
                return latest_match
            if time.monotonic() >= deadline:
                return latest_match
            time.sleep(poll_ms / 1000)

    def _require_control(self, action: str) -> None:
        if not self._control_enabled():
            raise PolicyBlockedError(
                f"{action} is disabled by policy. Set input.enabled=true and mode=control to enable computer control.",
                details={"mode": self.policy.mode, "input": self.policy.input},
            )
        allowed_actions = self.policy.input.get("allowed_actions")
        if allowed_actions and action not in allowed_actions:
            raise PolicyBlockedError(
                f"{action} is not in the policy input.allowed_actions allowlist.",
                details={"action": action, "allowed_actions": allowed_actions},
            )

    def _control_enabled(self) -> bool:
        return self.policy.mode == "control" and bool(self.policy.input.get("enabled", False))

    def _looks_sensitive(self, text: str) -> bool:
        lowered = text.lower()
        secret_markers = [
            "sk-",
            "api_key",
            "apikey",
            "access_token",
            "refresh_token",
            "password",
            "token",
            "secret",
            "private key",
            "seed phrase",
        ]
        return any(marker in lowered for marker in secret_markers)

    def _point_in_window(self, x: int, y: int, window: WindowInfo) -> bool:
        if window.bounds is None:
            return False
        return (
            window.bounds.x <= x <= window.bounds.x + window.bounds.width
            and window.bounds.y <= y <= window.bounds.y + window.bounds.height
        )

    def _check_rate_limit(self, action: str) -> None:
        max_events = int(self.policy.input.get("max_events_per_minute", 60))
        now = time.monotonic()
        self._input_event_times = [event_time for event_time in self._input_event_times if now - event_time < 60]
        if len(self._input_event_times) >= max_events:
            raise PolicyBlockedError(
                f"Input rate limit exceeded for {action}: {max_events} events per minute.",
                details={"action": action, "max_events_per_minute": max_events},
            )
        self._input_event_times.append(now)

    def _record_action(self, action: str, details: dict[str, Any], result: dict) -> dict:
        self._action_seq += 1
        action_id = f"act_{self._action_seq:06d}"
        payload = dict(result)
        payload.setdefault("ok", True)
        payload["action_id"] = action_id
        self._action_log.append(
            {
                "action_id": action_id,
                "action": action,
                "details": details,
                "ok": bool(payload.get("ok", False)),
                "recorded_at": round(time.time(), 3),
            }
        )
        return payload

    def _normalize_key(self, key: str) -> str:
        upper = key.upper()
        return _KEY_ALIASES.get(upper, upper)

    def _clamp_delta(self, value: int, max_delta: int) -> int:
        return max(-max_delta, min(max_delta, int(value)))

    def _evaluate_condition(self, condition: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
        condition_type = condition.get("type")
        if condition_type == "focused_window_title_contains":
            text = str(condition.get("text", "")).lower()
            window = self.backend.focused_window()
            observation = {"window": self._sanitize_window(window).model_dump() if window else None}
            title = window.title.lower() if window else ""
            return bool(text and text in title), observation

        if condition_type == "window_title_contains":
            text = str(condition.get("text", "")).lower()
            windows = self.backend.list_windows(include_minimized=True, limit=200)
            matching = [self._sanitize_window(window).model_dump() for window in windows if text and text in window.title.lower()]
            return bool(matching), {"matching_windows": matching}

        if condition_type == "window_exists":
            window_id = condition.get("window_id")
            windows = self.backend.list_windows(include_minimized=True, limit=200)
            matching = [self._sanitize_window(window).model_dump() for window in windows if window.window_id == window_id]
            return bool(matching), {"matching_windows": matching}

        if condition_type == "window_app_exists":
            app = str(condition.get("app", "")).lower()
            title_contains = str(condition.get("title_contains", "")).lower()
            windows = self.backend.list_windows(include_minimized=True, limit=200)
            matching = [
                self._sanitize_window(window).model_dump()
                for window in windows
                if app
                and (window.app or "").lower() == app
                and (not title_contains or title_contains in window.title.lower())
            ]
            return bool(matching), {"matching_windows": matching}

        raise PolicyBlockedError(
            "Unsupported wait_for condition type.",
            details={
                "condition": condition,
                "supported_types": [
                    "focused_window_title_contains",
                    "window_title_contains",
                    "window_exists",
                    "window_app_exists",
                ],
            },
        )

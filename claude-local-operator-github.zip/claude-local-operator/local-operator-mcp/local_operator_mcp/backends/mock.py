from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import parse_qs, urlparse

from ..models import Rect, ScreenshotImage, ScreenshotResult, UIElementInfo, UIInspectionResult, WindowInfo, WindowNotFoundError

_TINY_PNG_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII="


@dataclass
class MockBackend:
    name: str = "mock"

    def __post_init__(self) -> None:
        self._launched: list[dict] = []
        self._typed: list[str] = []
        self._clicks: list[dict] = []
        self._scrolls: list[dict] = []
        self._hotkeys: list[list[str]] = []
        self._windows = [
            WindowInfo(
                window_id="mock:notepad",
                title="Untitled - Notepad",
                app="notepad.exe",
                pid=1001,
                class_name="Notepad",
                focused=True,
                minimized=False,
                visible=True,
                bounds=Rect(x=40, y=40, width=900, height=600),
            ),
            WindowInfo(
                window_id="mock:code",
                title="local-operator-mcp - Visual Studio Code",
                app="Code.exe",
                pid=1002,
                class_name="Chrome_WidgetWin_1",
                focused=False,
                minimized=False,
                visible=True,
                bounds=Rect(x=100, y=100, width=1200, height=800),
            ),
        ]

    def list_windows(self, include_minimized: bool = True, limit: int = 50) -> list[WindowInfo]:
        windows = self._windows if include_minimized else [w for w in self._windows if not w.minimized]
        return windows[:limit]

    def focused_window(self) -> WindowInfo | None:
        return next((window for window in self._windows if window.focused), None)

    def screenshot(
        self,
        target: str = "screen",
        window_id: str | None = None,
        max_width: int = 1280,
        image_format: str = "jpeg",
    ) -> ScreenshotResult:
        window = self._resolve_window(target, window_id)
        return ScreenshotResult(
            target=target,
            window_id=window.window_id if window else None,
            image=ScreenshotImage(
                mime_type="image/png",
                base64=_TINY_PNG_BASE64,
                width=1,
                height=1,
            ),
            warning="Mock backend returned a synthetic 1x1 PNG; no real desktop pixels captured.",
        )

    def inspect_ui(
        self,
        target: str = "focused_window",
        window_id: str | None = None,
        max_depth: int = 4,
        max_nodes: int = 200,
        include_text: bool = True,
    ) -> UIInspectionResult:
        window = self._resolve_window(target, window_id)
        if window is None:
            raise WindowNotFoundError("inspect_ui requires focused_window or window_id target.")
        text = "".join(self._typed) if include_text else ""
        edit = UIElementInfo(
            element_id="mock:edit",
            role="Edit",
            name="Text Editor",
            automation_id="mock-edit",
            class_name="Edit",
            value=text,
            bounds=Rect(x=60, y=90, width=840, height=520),
            enabled=True,
            focused=True,
        )
        root = UIElementInfo(
            element_id="mock:root",
            role="Window",
            name=window.title,
            automation_id="mock-window",
            class_name=window.class_name,
            bounds=window.bounds,
            enabled=True,
            focused=window.focused,
            children=[edit] if max_depth > 0 and max_nodes > 1 else [],
        )
        elements = [root]
        if root.children:
            elements.extend(root.children[: max(0, max_nodes - 1)])
        return UIInspectionResult(
            target=target,
            window_id=window.window_id,
            backend=self.name,
            root=root,
            elements=elements[:max_nodes],
            text_preview=text,
            truncated=len(elements) > max_nodes,
            warning="Mock backend returned a synthetic UI tree; no real desktop accessibility data captured.",
        )

    def window_focus(self, window_id: str) -> dict:
        target = None
        for window in self._windows:
            if window.window_id == window_id:
                target = window
        if target is None:
            raise WindowNotFoundError(f"Unknown mock window_id: {window_id}")
        for index, window in enumerate(self._windows):
            data = window.model_dump()
            data["focused"] = window.window_id == window_id
            self._windows[index] = WindowInfo.model_validate(data)
        return {"ok": True, "window_id": window_id, "focused": True}

    def app_launch(self, app_id: str, args: list[str] | None = None) -> dict:
        launch_args = args or []
        event = {"app_id": app_id, "args": launch_args, "pid": 9000 + len(self._launched)}
        self._launched.append(event)
        if app_id in {"msedge.exe", "chrome.exe"}:
            self._upsert_browser_window(app_id, launch_args, event["pid"])
        return {"ok": True, **event}

    def input_hotkey(self, keys: list[str]) -> dict:
        self._hotkeys.append(keys)
        return {"ok": True, "keys": keys}

    def input_type_text(self, text: str, method: str = "paste") -> dict:
        self._typed.append(text)
        return {"ok": True, "method": method, "characters": len(text)}

    def input_click(
        self,
        x: int,
        y: int,
        button: str = "left",
        clicks: int = 1,
        window_id: str | None = None,
    ) -> dict:
        event = {"x": x, "y": y, "button": button, "clicks": clicks, "window_id": window_id}
        self._clicks.append(event)
        return {"ok": True, **event}

    def input_scroll(self, delta_y: int, delta_x: int = 0, window_id: str | None = None) -> dict:
        event = {"delta_y": delta_y, "delta_x": delta_x, "window_id": window_id}
        self._scrolls.append(event)
        return {"ok": True, **event}

    def _upsert_browser_window(self, app_id: str, args: list[str], pid: int) -> None:
        url = next((item for item in reversed(args) if item.startswith(("http://", "https://"))), "")
        parsed = urlparse(url)
        query = parse_qs(parsed.query).get("q", [""])[0]
        product = "Microsoft Edge" if app_id == "msedge.exe" else "Google Chrome"
        title_subject = query or parsed.netloc or "New tab"
        window_id = f"mock:{app_id.removesuffix('.exe')}"
        browser = WindowInfo(
            window_id=window_id,
            title=f"{title_subject} - Search - {product}",
            app=app_id,
            pid=pid,
            class_name="Chrome_WidgetWin_1",
            focused=True,
            minimized=False,
            visible=True,
            bounds=Rect(x=80, y=80, width=1280, height=820),
        )
        self._windows = [WindowInfo.model_validate({**window.model_dump(), "focused": False}) for window in self._windows]
        for index, window in enumerate(self._windows):
            if window.window_id == window_id:
                self._windows[index] = browser
                break
        else:
            self._windows.insert(0, browser)

    def _resolve_window(self, target: str, window_id: str | None) -> WindowInfo | None:
        if target == "screen":
            return None
        if target == "focused_window":
            return self.focused_window()
        if target == "window_id":
            for window in self._windows:
                if window.window_id == window_id:
                    return window
            raise WindowNotFoundError(f"Unknown mock window_id: {window_id}")
        return None

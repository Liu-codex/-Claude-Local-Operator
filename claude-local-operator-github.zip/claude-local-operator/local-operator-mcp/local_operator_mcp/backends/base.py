from __future__ import annotations

from typing import Protocol

from ..models import ScreenshotResult, UIInspectionResult, WindowInfo


class DesktopBackend(Protocol):
    name: str

    def list_windows(self, include_minimized: bool = True, limit: int = 50) -> list[WindowInfo]:
        ...

    def focused_window(self) -> WindowInfo | None:
        ...

    def screenshot(
        self,
        target: str = "screen",
        window_id: str | None = None,
        max_width: int = 1280,
        image_format: str = "jpeg",
    ) -> ScreenshotResult:
        ...

    def inspect_ui(
        self,
        target: str = "focused_window",
        window_id: str | None = None,
        max_depth: int = 4,
        max_nodes: int = 200,
        include_text: bool = True,
    ) -> UIInspectionResult:
        ...

    def window_focus(self, window_id: str) -> dict:
        ...

    def app_launch(self, app_id: str, args: list[str] | None = None) -> dict:
        ...

    def input_hotkey(self, keys: list[str]) -> dict:
        ...

    def input_type_text(self, text: str, method: str = "paste") -> dict:
        ...

    def input_click(
        self,
        x: int,
        y: int,
        button: str = "left",
        clicks: int = 1,
        window_id: str | None = None,
    ) -> dict:
        ...

    def input_scroll(self, delta_y: int, delta_x: int = 0, window_id: str | None = None) -> dict:
        ...

from __future__ import annotations

import os
import platform

from .base import DesktopBackend
from .mock import MockBackend
from .windows import WindowsBackend
from ..models import DependencyMissingError


def create_backend(name: str | None = None) -> DesktopBackend:
    requested = (name or os.environ.get("LOCAL_OPERATOR_BACKEND") or "auto").lower()
    if requested == "mock":
        return MockBackend()
    if requested == "windows":
        return WindowsBackend()
    if requested != "auto":
        raise ValueError(f"Unknown backend: {requested}")

    if platform.system() == "Windows":
        try:
            return WindowsBackend()
        except DependencyMissingError:
            # Auto mode should remain usable for development/tests even without pywin32.
            return MockBackend()
    return MockBackend()

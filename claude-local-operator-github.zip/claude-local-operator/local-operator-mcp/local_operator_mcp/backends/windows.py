from __future__ import annotations

import base64
import io
import os
import platform
import shutil
import subprocess
import time
from dataclasses import dataclass, field

from ..models import DependencyMissingError, Rect, ScreenshotImage, ScreenshotResult, WindowInfo, WindowNotFoundError

try:  # pragma: no cover - imports are platform dependent
    import psutil
    import win32con
    import win32gui
    import win32process
    import mss
    import pyautogui
    from PIL import Image
except Exception as exc:  # pragma: no cover - platform dependent
    psutil = None
    win32con = None
    win32gui = None
    win32process = None
    mss = None
    pyautogui = None
    Image = None
    _IMPORT_ERROR = exc
else:  # pragma: no cover - platform dependent
    _IMPORT_ERROR = None


@dataclass
class WindowsBackend:
    name: str = "windows"
    _hwnd_to_window_id: dict[int, str] = field(default_factory=dict)
    _window_id_to_hwnd: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if platform.system() != "Windows":
            raise DependencyMissingError("Windows backend is only available on Windows.")
        if _IMPORT_ERROR is not None:
            raise DependencyMissingError(
                "Windows backend requires pywin32, psutil, mss, pillow, and pyautogui.",
                details=str(_IMPORT_ERROR),
            )
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.05

    def list_windows(self, include_minimized: bool = True, limit: int = 50) -> list[WindowInfo]:
        active_hwnd = win32gui.GetForegroundWindow()
        windows: list[WindowInfo] = []

        def callback(hwnd: int, _extra: object) -> bool:
            if len(windows) >= limit:
                return False
            if not win32gui.IsWindowVisible(hwnd):
                return True
            if not include_minimized and win32gui.IsIconic(hwnd):
                return True
            title = win32gui.GetWindowText(hwnd) or ""
            if not title.strip():
                return True

            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            app = _process_name(pid)
            left, top, right, bottom = [int(v) for v in win32gui.GetWindowRect(hwnd)]
            window_id = self._window_id_for(hwnd)
            windows.append(
                WindowInfo(
                    window_id=window_id,
                    title=title,
                    app=app,
                    pid=pid,
                    class_name=win32gui.GetClassName(hwnd),
                    focused=hwnd == active_hwnd,
                    minimized=bool(win32gui.IsIconic(hwnd)),
                    visible=True,
                    bounds=Rect(x=left, y=top, width=max(0, right - left), height=max(0, bottom - top)),
                )
            )
            return True

        win32gui.EnumWindows(callback, None)
        return windows

    def focused_window(self) -> WindowInfo | None:
        hwnd = win32gui.GetForegroundWindow()
        if not hwnd:
            return None
        for window in self.list_windows(include_minimized=True, limit=200):
            if window.window_id == self._window_id_for(hwnd):
                return window
        return None

    def screenshot(
        self,
        target: str = "screen",
        window_id: str | None = None,
        max_width: int = 1280,
        image_format: str = "jpeg",
    ) -> ScreenshotResult:
        monitor = self._monitor_for_target(target, window_id)
        with mss.mss() as sct:
            raw = sct.grab(monitor)
            image = Image.frombytes("RGB", raw.size, raw.rgb)

        if image.width > max_width:
            ratio = max_width / image.width
            image = image.resize((max_width, max(1, int(image.height * ratio))))

        mime_type, encoded = _encode_image(image, image_format)
        return ScreenshotResult(
            target=target,
            window_id=window_id if target == "window_id" else None,
            image=ScreenshotImage(mime_type=mime_type, base64=encoded, width=image.width, height=image.height),
        )

    def window_focus(self, window_id: str) -> dict:
        hwnd = self._hwnd_for_window_id(window_id)
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
        try:
            win32gui.SetForegroundWindow(hwnd)
        except Exception:
            # Windows sometimes rejects direct foreground changes. Try a benign
            # restore/show path once, then report the actual foreground state.
            win32gui.BringWindowToTop(hwnd)
        deadline = time.monotonic() + 0.25
        focused = win32gui.GetForegroundWindow() == hwnd
        while not focused and time.monotonic() < deadline:
            time.sleep(0.02)
            focused = win32gui.GetForegroundWindow() == hwnd
        return {"ok": focused, "window_id": window_id, "focused": focused}

    def app_launch(self, app_id: str, args: list[str] | None = None) -> dict:
        command = _resolve_executable(app_id)
        proc = subprocess.Popen([command, *(args or [])], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True, "pid": proc.pid, "app_id": app_id, "command": command}

    def input_hotkey(self, keys: list[str]) -> dict:
        pyautogui.hotkey(*[_pyautogui_key(key) for key in keys])
        return {"ok": True, "keys": keys}

    def input_type_text(self, text: str, method: str = "paste") -> dict:
        if method == "paste":
            try:
                _set_clipboard_text(text)
                pyautogui.hotkey("ctrl", "v")
                return {"ok": True, "method": "paste", "characters": len(text)}
            except Exception:
                # Fall back to typing when clipboard is unavailable.
                pass
        pyautogui.write(text, interval=0.01)
        return {"ok": True, "method": "type", "characters": len(text)}

    def input_click(
        self,
        x: int,
        y: int,
        button: str = "left",
        clicks: int = 1,
        window_id: str | None = None,
    ) -> dict:
        if window_id:
            hwnd = self._hwnd_for_window_id(window_id)
            left, top, right, bottom = [int(v) for v in win32gui.GetWindowRect(hwnd)]
            if not (left <= x <= right and top <= y <= bottom):
                raise WindowNotFoundError(f"Click coordinate ({x}, {y}) is outside window {window_id} bounds.")
        pyautogui.click(x=x, y=y, button=button, clicks=clicks)
        return {"ok": True, "x": x, "y": y, "button": button, "clicks": clicks, "window_id": window_id}

    def input_scroll(self, delta_y: int, delta_x: int = 0, window_id: str | None = None) -> dict:
        if window_id:
            self._hwnd_for_window_id(window_id)
        if delta_x:
            try:
                pyautogui.hscroll(delta_x)
            except Exception as exc:
                raise WindowNotFoundError("Horizontal scroll is not available in this Windows backend.") from exc
        if delta_y:
            pyautogui.scroll(delta_y)
        return {"ok": True, "delta_y": delta_y, "delta_x": delta_x, "window_id": window_id}

    def _window_id_for(self, hwnd: int) -> str:
        if hwnd in self._hwnd_to_window_id:
            return self._hwnd_to_window_id[hwnd]
        window_id = f"win:{hwnd:x}"
        self._hwnd_to_window_id[hwnd] = window_id
        self._window_id_to_hwnd[window_id] = hwnd
        return window_id

    def _hwnd_for_window_id(self, window_id: str | None) -> int:
        if not window_id:
            raise WindowNotFoundError("window_id is required.")
        hwnd = self._window_id_to_hwnd.get(window_id)
        if hwnd is None:
            self.list_windows(include_minimized=True, limit=200)
            hwnd = self._window_id_to_hwnd.get(window_id)
        if hwnd is None or not win32gui.IsWindow(hwnd):
            raise WindowNotFoundError(f"Unknown or stale window_id: {window_id}")
        return hwnd

    def _monitor_for_target(self, target: str, window_id: str | None) -> dict[str, int]:
        if target == "screen":
            with mss.mss() as sct:
                return dict(sct.monitors[1])
        if target == "focused_window":
            hwnd = win32gui.GetForegroundWindow()
        elif target == "window_id":
            hwnd = self._hwnd_for_window_id(window_id)
        else:
            raise WindowNotFoundError(f"Unsupported screenshot target: {target}")

        left, top, right, bottom = [int(v) for v in win32gui.GetWindowRect(hwnd)]
        return {"left": left, "top": top, "width": max(1, right - left), "height": max(1, bottom - top)}


def _resolve_executable(app_id: str) -> str:
    resolved = shutil.which(app_id)
    if resolved:
        return resolved
    if app_id.lower() == "msedge.exe":
        candidates = [
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(os.environ.get("LocalAppData", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
        ]
    elif app_id.lower() == "chrome.exe":
        candidates = [
            os.path.join(os.environ.get("ProgramFiles", ""), "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("LocalAppData", ""), "Google", "Chrome", "Application", "chrome.exe"),
        ]
    else:
        candidates = []
    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate
    return app_id


def _process_name(pid: int) -> str | None:
    try:
        return psutil.Process(pid).name() if psutil else None
    except Exception:
        return None


def _encode_image(image: object, image_format: str) -> tuple[str, str]:
    fmt = "PNG" if image_format.lower() == "png" else "JPEG"
    mime_type = "image/png" if fmt == "PNG" else "image/jpeg"
    buffer = io.BytesIO()
    kwargs = {} if fmt == "PNG" else {"quality": 75}
    image.save(buffer, format=fmt, **kwargs)
    return mime_type, base64.b64encode(buffer.getvalue()).decode("ascii")


def _pyautogui_key(key: str) -> str:
    aliases = {
        "CTRL": "ctrl",
        "CONTROL": "ctrl",
        "ALT": "alt",
        "SHIFT": "shift",
        "WIN": "win",
        "WINDOWS": "win",
        "ENTER": "enter",
        "ESC": "esc",
        "ESCAPE": "esc",
        "DEL": "delete",
        "DELETE": "delete",
        "PGUP": "pageup",
        "PGDN": "pagedown",
    }
    upper = key.upper()
    return aliases.get(upper, key.lower())


def _set_clipboard_text(text: str) -> None:
    import win32clipboard

    win32clipboard.OpenClipboard()
    try:
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_UNICODETEXT, text)
    finally:
        win32clipboard.CloseClipboard()

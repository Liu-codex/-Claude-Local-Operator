from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .service import LocalOperatorService

CONTROL_POLICY = "E:/code/local-operator-mcp/configs/policy.control.json"


@dataclass
class CheckResult:
    name: str
    ok: bool
    message: str = ""

    def model_dump(self) -> dict:
        return {"name": self.name, "ok": self.ok, "message": self.message}


def run_self_test(control_policy: str = CONTROL_POLICY) -> dict:
    """Run dependency-light smoke checks without pytest or the MCP package."""
    checks: list[CheckResult] = []

    def check(name: str, fn: Callable[[], None]) -> None:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001 - self-test should report all failures.
            checks.append(CheckResult(name=name, ok=False, message=str(exc)))
        else:
            checks.append(CheckResult(name=name, ok=True))

    check("read_only_capabilities", _check_read_only_capabilities)
    check("mock_observation", _check_mock_observation)
    check("read_only_blocks_control", _check_read_only_blocks_control)
    check("control_actions", lambda: _check_control_actions(control_policy))
    check("browser_actions", lambda: _check_browser_actions(control_policy))
    check("wait_for", _check_wait_for)
    check("safety_boundaries", lambda: _check_safety_boundaries(control_policy))

    failed = [item for item in checks if not item.ok]
    return {
        "ok": not failed,
        "backend": "mock",
        "checks": [item.model_dump() for item in checks],
        "summary": f"{len(checks) - len(failed)}/{len(checks)} checks passed",
    }


def _check_read_only_capabilities() -> None:
    service = LocalOperatorService(backend_name="mock")
    policy = service.get_policy()
    assert policy["mode"] == "read_only"
    assert policy["capabilities"]["backend"] == "mock"
    assert "window_list" in policy["capabilities"]["tools"]
    assert "wait_for" in policy["capabilities"]["tools"]
    assert "input_scroll" in policy["capabilities"]["disabled_until_future_phase"]
    assert "open_url" in policy["capabilities"]["disabled_until_future_phase"]
    assert "browser_search" in policy["capabilities"]["disabled_until_future_phase"]


def _check_mock_observation() -> None:
    service = LocalOperatorService(backend_name="mock")
    windows = service.window_list()["windows"]
    assert windows
    assert windows[0]["window_id"].startswith("mock:")
    assert service.focused_window()["window"]["focused"] is True
    screenshot = service.screenshot(target="focused_window", max_width=640)
    assert screenshot["image"]["base64"]
    assert screenshot["image"]["width"] <= 640


def _check_read_only_blocks_control() -> None:
    service = LocalOperatorService(backend_name="mock")
    try:
        service.input_type_text("hello")
    except Exception as exc:  # noqa: BLE001
        assert "disabled by policy" in str(exc)
    else:
        raise AssertionError("read-only policy allowed input_type_text")

    try:
        service.browser_search("Claude")
    except Exception as exc:  # noqa: BLE001
        assert "disabled by policy" in str(exc)
    else:
        raise AssertionError("read-only policy allowed browser_search")


def _check_control_actions(control_policy: str) -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=control_policy)
    target = service.window_list()["windows"][1]["window_id"]
    assert service.window_focus(target)["ok"] is True
    assert service.app_launch("notepad")["ok"] is True
    assert service.input_hotkey(["CTRL", "A"])["ok"] is True
    assert service.input_type_text("safe test text")["ok"] is True
    assert service.input_click(120, 120, window_id=target)["ok"] is True
    assert service.input_scroll(-600, window_id=target)["ok"] is True
    assert len(service.action_history()["actions"]) >= 6


def _check_browser_actions(control_policy: str) -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=control_policy)
    assert service.app_launch("edge")["app_id"] == "msedge.exe"
    opened = service.open_url("https://example.com", browser="edge")
    assert opened["ok"] is True
    assert opened["window"]["app"] == "msedge.exe"
    searched = service.browser_search("Claude", browser="edge", engine="bing")
    assert searched["ok"] is True
    assert searched["url"] == "https://www.bing.com/search?q=Claude"

    try:
        service.open_url("file:///C:/Windows/win.ini")
    except Exception as exc:  # noqa: BLE001
        assert "http" in str(exc).lower() or "url" in str(exc).lower()
    else:
        raise AssertionError("unsafe URL was not blocked")


def _check_wait_for() -> None:
    service = LocalOperatorService(backend_name="mock")
    matched = service.wait_for({"type": "focused_window_title_contains", "text": "Notepad"}, timeout_ms=200)
    assert matched["matched"] is True
    timed_out = service.wait_for(
        {"type": "window_title_contains", "text": "definitely-not-present"},
        timeout_ms=120,
        poll_ms=50,
    )
    assert timed_out["ok"] is True
    assert timed_out["matched"] is False


def _check_safety_boundaries(control_policy: str) -> None:
    service = LocalOperatorService(backend_name="mock", policy_path=control_policy)
    try:
        service.input_type_text("sk-secret-token")
    except Exception as exc:  # noqa: BLE001
        assert "secret" in str(exc).lower()
    else:
        raise AssertionError("secret-looking text was not blocked")

    try:
        service.browser_search("sk-secret-token")
    except Exception as exc:  # noqa: BLE001
        assert "secret" in str(exc).lower()
    else:
        raise AssertionError("secret-looking query was not blocked")

    try:
        service.input_hotkey(["control", "alt", "del"])
    except Exception as exc:  # noqa: BLE001
        assert "blocked" in str(exc).lower()
    else:
        raise AssertionError("dangerous hotkey was not blocked")

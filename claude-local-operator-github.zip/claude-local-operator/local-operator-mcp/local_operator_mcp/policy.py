from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

try:
    import yaml
except Exception:  # pragma: no cover - optional dependency for --check before install
    yaml = None

from .models import Policy

DEFAULT_POLICY_PATH = Path(__file__).resolve().parent.parent / "configs" / "policy.readonly.yaml"


def load_policy(path: str | os.PathLike[str] | None = None) -> Policy:
    raw_path = Path(path or os.environ.get("LOCAL_OPERATOR_POLICY", DEFAULT_POLICY_PATH))
    if not raw_path.exists():
        return Policy(notes=[f"Policy file not found: {raw_path}. Using built-in read-only defaults."])

    if raw_path.suffix.lower() != ".json" and yaml is None:
        # Keep `--check` usable before PyYAML is installed. The built-in Policy
        # defaults are deliberately safe/read-only and include sensitive-window
        # screenshot deny patterns.
        return Policy(notes=[f"PyYAML is not installed; using built-in defaults instead of {raw_path}."])

    data = _read_mapping(raw_path)
    policy = Policy.model_validate(data)
    policy.notes.append(f"Loaded policy from {raw_path}")
    return policy


def _read_mapping(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        data = json.loads(text)
    else:
        data = yaml.safe_load(text) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Policy must be a mapping: {path}")
    return data

from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


_DEFAULT_DENY_PATTERNS = [
    "password",
    "1password",
    "bitwarden",
    "keepass",
    "keepassxc",
    "wallet",
    "seed phrase",
    "private key",
    "token",
    "secret",
]


class Rect(BaseModel):
    x: int
    y: int
    width: int
    height: int


class WindowInfo(BaseModel):
    window_id: str
    title: str
    app: str | None = None
    pid: int | None = None
    class_name: str | None = None
    focused: bool = False
    minimized: bool = False
    visible: bool = True
    bounds: Rect | None = None


class ScreenshotImage(BaseModel):
    mime_type: str
    base64: str
    width: int
    height: int


class ScreenshotResult(BaseModel):
    target: str
    window_id: str | None = None
    image: ScreenshotImage
    coordinate_system: Literal["physical_pixels"] = "physical_pixels"
    warning: str | None = None


class UIElementInfo(BaseModel):
    element_id: str
    role: str
    name: str = ""
    automation_id: str | None = None
    class_name: str | None = None
    value: str | None = None
    bounds: Rect | None = None
    enabled: bool | None = None
    focused: bool | None = None
    children: list["UIElementInfo"] = Field(default_factory=list)


class UIInspectionResult(BaseModel):
    target: str
    window_id: str | None = None
    backend: str
    root: UIElementInfo | None = None
    elements: list[UIElementInfo] = Field(default_factory=list)
    text_preview: str = ""
    truncated: bool = False
    coordinate_system: Literal["physical_pixels"] = "physical_pixels"
    warning: str | None = None


class Policy(BaseModel):
    mode: str = "read_only"
    backend: str = "auto"
    observation: dict[str, Any] = Field(default_factory=dict)
    apps: dict[str, list[str]] = Field(default_factory=lambda: {"allow": [], "deny": list(_DEFAULT_DENY_PATTERNS)})
    screenshots: dict[str, Any] = Field(default_factory=dict)
    input: dict[str, Any] = Field(default_factory=lambda: {"enabled": False})
    confirm: dict[str, list[str]] = Field(default_factory=lambda: {"always": []})
    audit: dict[str, Any] = Field(default_factory=lambda: {"enabled": False})
    notes: list[str] = Field(default_factory=list)


class ToolError(Exception):
    code = "TOOL_ERROR"

    def __init__(self, message: str, details: Any | None = None) -> None:
        super().__init__(message)
        self.details = details


class DependencyMissingError(ToolError):
    code = "DEPENDENCY_MISSING"


class WindowNotFoundError(ToolError):
    code = "WINDOW_NOT_FOUND"


class PolicyBlockedError(ToolError):
    code = "POLICY_BLOCKED"

# local-operator-mcp

Windows-first MCP server for the `claude-local-operator` skill.

This is the runtime half of the local computer operator. It supports read-only observation plus policy-gated, reversible control actions.

## Tools

Observation:

- `get_policy` — show active safety policy and capabilities;
- `action_history` — show recent policy-gated actions performed by this server process;
- `window_list` — list visible desktop windows;
- `focused_window` — identify the focused window;
- `screenshot` — capture the screen, focused window, or a known window;
- `wait_for` — poll for a safe UI condition such as a matching window title.

Control, only when policy enables `mode: control` and `input.enabled: true`:

- `window_focus` — focus a known window;
- `app_launch` — launch safe aliases such as `notepad`, `calc`, `edge`, or `chrome`, or policy-allowlisted executables;
- `open_url` — open an HTTP(S) URL in Edge or Chrome without keyboarding into the address bar;
- `browser_search` — search the web in Edge or Chrome as one high-level action;
- `input_hotkey` — send non-dangerous keyboard shortcuts;
- `input_type_text` — paste/type non-sensitive text;
- `input_click` — click coordinates, optionally bounded to a known window;
- `input_scroll` — scroll the focused window or a known window.

## Browser shortcuts

Browser aliases:

- `edge`, `msedge`, `microsoft_edge` → `msedge.exe`
- `chrome`, `google_chrome` → `chrome.exe`

The browser executable still has to be allowed by policy (`apps.allow`). The control policy in `configs/policy.control.json` allows both `msedge.exe` and `chrome.exe`.

Examples:

```text
Use claude-local-operator. Open https://claude.ai in Edge.
```

```text
Use claude-local-operator. Search for "Claude Code MCP docs" in Edge.
```

`open_url` and `browser_search` are faster and safer than a low-level sequence of focus → Ctrl+L → paste → Enter because they launch the browser directly with the target URL and then wait for a browser window.

Browser safety limits:

- Browser actions are control-mode only.
- Only `http://` and `https://` URLs are allowed.
- `file:`, `javascript:`, `data:`, `about:`, browser-internal schemes, and custom protocols are blocked.
- Secret-looking URLs or queries are blocked (`token`, `api_key`, `password`, `sk-`, etc.).
- The tools navigate/open/search only; they do not submit forms, log in, or handle credentials.

## Install

```bash
cd E:/code/local-operator-mcp
python -m pip install -e ".[windows,test]"
```

If dependencies are missing, mock and `--check` modes still work for development.

## Check capabilities

Dependency-light self-test (no pytest required):

```bash
python -m local_operator_mcp.server --self-test
```

Read-only mock:

```bash
python -m local_operator_mcp.server --backend mock --check
```

Control mock:

```bash
python -m local_operator_mcp.server --backend mock --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

Real Windows control:

```bash
python -m local_operator_mcp.server --backend windows --policy E:/code/local-operator-mcp/configs/policy.control.json --check
```

## Claude Code MCP config

Read-only mode:

```json
{
  "mcpServers": {
    "local-operator": {
      "command": "python",
      "args": ["-m", "local_operator_mcp.server"],
      "cwd": "E:/code/local-operator-mcp",
      "env": {
        "LOCAL_OPERATOR_POLICY": "E:/code/local-operator-mcp/configs/policy.readonly.yaml"
      }
    }
  }
}
```

Control mode:

```json
{
  "mcpServers": {
    "local-operator": {
      "command": "python",
      "args": ["-m", "local_operator_mcp.server"],
      "cwd": "E:/code/local-operator-mcp",
      "env": {
        "LOCAL_OPERATOR_POLICY": "E:/code/local-operator-mcp/configs/policy.control.json"
      }
    }
  }
}
```

## Safe first prompt

After MCP is connected, test with:

```text
Use claude-local-operator. Open Notepad, type "Claude local operator control test", wait until the focused window title contains Notepad, verify it is visible, then stop. Do not save or close anything.
```

For a fast browser smoke test:

```text
Use claude-local-operator. Search for Claude in Edge, verify an Edge window appears, then stop.
```

## Safety limits still active

- Secret-looking text is blocked.
- Long text pastes/searches are capped by policy (`input.max_text_chars`, default 5000; browser search also caps at 1000).
- Sensitive windows matching deny patterns are blocked.
- Dangerous shortcuts such as Alt+F4, Shift+Delete, Ctrl+Alt+Delete, Ctrl+W, Ctrl+Q, and Win+R are blocked.
- Input/control actions are rate-limited by policy (`input.max_events_per_minute`).
- App launching is restricted to safe aliases and allowlisted executables.
- Browser navigation is restricted to HTTP(S) in allowed browsers.
- Clicks can be bounded to a known window and are rejected if outside the target window.
- Scroll deltas are clamped by policy (`input.max_scroll_delta`, default 1200).
